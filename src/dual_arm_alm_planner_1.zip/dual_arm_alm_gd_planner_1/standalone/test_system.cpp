// =====================================================================
// test_system.cpp — AvoidanceSystem 壓力測試 / 崩潰定位
// =====================================================================
//   用法:
//     ./test_system single <j1> <j2> <j3>     單一 case (詳細輸出)
//     ./test_system scan                        角度掃描 (找崩潰 case)
//     ./test_system moveit                      模擬 MoveIt 連續多次規劃
//
//   建議用 -fsanitize=address 編譯; 崩潰時 ASan 會印出精確的 .cpp 行號
// =====================================================================
#include "dual_arm_alm_gd_planner_1/avoidance_system.hpp"
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <string>

using namespace dual_arm_alm_gd_planner_1;

// 跑一個 case, 回傳是否成功 (不崩 = true)
static bool run_one(double j1, double j2, double j3, bool verbose)
{
  Eigen::MatrixXd A(2, 6), B(2, 6);
  // A 臂: J1 從 -j1 掃到 +j1 (中段會經過危險區)
  A << -j1, j2, j3, 0, -7.8, 0,
        j1, j2, j3, 0, -7.8, 0;
  // B 臂: 對稱往反方向
  B <<  j1, -19.8, -29.8, 0, 49.6, 0,
       -j1, -19.8, -29.8, 0, 49.6, 0;

  if (verbose) {
    std::cout << "===== Case j1=" << j1 << " j2=" << j2 << " j3=" << j3 << " =====\n";
  }

  AvoidanceSystem sys(A, B, 0.5, 0.4);
  sys.run_optimization();

  if (verbose) {
    std::cout << "  is_optimized=" << sys.is_optimized()
              << " has_collision=" << sys.has_collision()
              << " 原始點=" << sys.get_original_trajectory().time.size()
              << " 優化點=" << sys.get_optimized_trajectory().time.size() << "\n";
  }
  return true;
}

// ===== 模式 1: 單一 case =====
static int mode_single(int argc, char** argv)
{
  double j1 = (argc > 2) ? std::atof(argv[2]) : 30.0;
  double j2 = (argc > 3) ? std::atof(argv[3]) : -30.8;
  double j3 = (argc > 4) ? std::atof(argv[4]) : 38.6;
  run_one(j1, j2, j3, true);
  std::cout << "[single] 完成, 無崩潰\n";
  return 0;
}

// ===== 模式 2: 角度掃描 =====
static int mode_scan()
{
  int n = 0, fail = 0;
  // 掃 j1 (軌跡幅度), j2/j3 (手臂姿態 -> 改變撞的位置與深度)
  for (double j1 = 20; j1 <= 80; j1 += 5) {
    for (double j2 = -50; j2 <= 10; j2 += 15) {
      for (double j3 = 20; j3 <= 50; j3 += 15) {
        std::cout << "[scan] j1=" << j1 << " j2=" << j2 << " j3=" << j3 << std::flush;
        run_one(j1, j2, j3, false);   // 若崩潰, ASan 會在此 case 印行號後 abort
        std::cout << "  ok\n";
        ++n;
      }
    }
  }
  std::cout << "[scan] 掃完 " << n << " 個 case, 失敗 " << fail << "\n";
  return 0;
}

// ===== 模式 3: 模擬 MoveIt 連續規劃 =====
//   你的崩潰是「多次規劃後某次」發生, 這裡重現該情境:
//   每次用新的 AvoidanceSystem 物件 (跟 MoveIt 每次 new 一個 PlanningContext 一樣)
static int mode_moveit()
{
  // 一組會反覆規劃的 waypoints (模擬使用者在 RViz 反覆拖)
  struct WP { double a1s, a1e, j2, j3; };
  WP seq[] = {
    {-30,  30, -30.8, 38.6},
    { 30, -30, -30.8, 38.6},
    {-45,  45, -20,   40},
    { 45, -45, -20,   40},
    {-60,  60, -10,   45},
    {-15,  15, -40,   30},   // 短軌跡
    {-70,  70,   0,   50},
  };
  int round = 0;
  for (int rep = 0; rep < 5; ++rep) {       // 重複 5 輪
    for (auto& w : seq) {
      ++round;
      std::cout << "[moveit] 規劃 #" << round
                << " (j1 " << w.a1s << "->" << w.a1e << ")" << std::flush;
      Eigen::MatrixXd A(2, 6), B(2, 6);
      A << w.a1s, w.j2, w.j3, 0, -7.8, 0,   w.a1e, w.j2, w.j3, 0, -7.8, 0;
      B << -w.a1s, -19.8, -29.8, 0, 49.6, 0, -w.a1e, -19.8, -29.8, 0, 49.6, 0;
      AvoidanceSystem sys(A, B, 0.5, 0.4);  // 每次 new 一個 (同 MoveIt)
      sys.run_optimization();
      std::cout << "  ok (col=" << sys.has_collision() << ")\n";
    }
  }
  std::cout << "[moveit] 連續 " << round << " 次規劃完成, 無崩潰\n";
  return 0;
}

int main(int argc, char** argv)
{
  std::string mode = (argc > 1) ? argv[1] : "single";
  std::cout << std::fixed << std::setprecision(3);

  if (mode == "single") return mode_single(argc, argv);
  if (mode == "scan")   return mode_scan();
  if (mode == "moveit") return mode_moveit();

  std::cerr << "未知模式: " << mode << " (single/scan/moveit)\n";
  return 2;
}
