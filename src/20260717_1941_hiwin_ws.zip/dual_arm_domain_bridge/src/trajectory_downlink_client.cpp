// [來源] 新建檔案 — 下行 client（Plan B 程式 2/2，事件式）
// = dual_arm_topic_client 的核心邏輯（捕捉/拆分/監看/取消）+ 兩個差異:
//   ① 去前綴: big_joint_1 → joint_1（原廠控制器只認無前綴名）
//   ② 發布改在各臂的 context 進行（同名 topic、不同 domain、互不干擾）
//
//   ctx_host (D10): 訂 /display_planned_path（捕捉, 前綴名、radian）
//                   訂 /joint_states（完成監看 — 直接吃上行橋的合併輸出）
//                   srv ~/execute、~/cancel
//   ctx_armA (D11): 發 /joint_trajectory_controller/joint_trajectory（A 份, 去前綴）
//   ctx_armB (D12): 發 同名 topic（B 份, 去前綴）
//
// 同步: header.stamp=0（收到即跑）, 兩筆 publish 連續執行差毫秒級 — 不需 NTP
// 取消: 空軌跡 = 標準 JTC 停止語意
// Panel 對接: kClientNode 改 "/trajectory_downlink_client" 即可
//
// 用法: ros2 run dual_arm_domain_bridge trajectory_downlink_client [host_d armA_d armB_d]
//       預設 domain: host=10, armA=11, armB=12

#include "dual_arm_domain_bridge/multi_context.hpp"

#include <moveit_msgs/msg/display_trajectory.hpp>
#include <trajectory_msgs/msg/joint_trajectory.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <std_srvs/srv/trigger.hpp>

#include <cmath>
#include <cstdlib>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

using dual_arm_domain_bridge::DomainNode;
using dual_arm_domain_bridge::make_domain_node;
using trajectory_msgs::msg::JointTrajectory;

namespace
{

// ---- 設定 ----
const char * kPrefixA = "big_";      // 拆分選擇 + 去前綴用
const char * kPrefixB = "small_";
const char * kArmTopic = "/joint_trajectory_controller/joint_trajectory";  // 原廠 JTC topic
constexpr double kGoalTolerance = 0.01;   // rad
constexpr double kTimeoutMargin = 2.0;    // 秒

struct SharedState
{
  std::mutex mtx;
  JointTrajectory latest;                  // 最新捕捉的 12 軸規劃（前綴名）
  bool have_plan{false};
  bool executing{false};
  std::map<std::string, double> targets;   // 前綴名 → 末點位置
  std::map<std::string, double> current;   // 前綴名 → 目前位置（來自 D10 合併 joint_states）
  rclcpp::Time deadline{0, 0, RCL_ROS_TIME};
};

// 依前綴挑出該臂欄位, 並「去前綴」(big_joint_1 → joint_1, 原廠控制器只認這個)
JointTrajectory split_and_strip(const JointTrajectory & full, const std::string & prefix)
{
  JointTrajectory out;
  std::vector<size_t> idx;
  for (size_t i = 0; i < full.joint_names.size(); ++i) {
    if (full.joint_names[i].rfind(prefix, 0) == 0) {     // 以 prefix 開頭
      idx.push_back(i);
      out.joint_names.push_back(full.joint_names[i].substr(prefix.size()));  // 去前綴
    }
  }
  out.points.reserve(full.points.size());
  for (const auto & p : full.points) {
    trajectory_msgs::msg::JointTrajectoryPoint q;
    q.time_from_start = p.time_from_start;   // 原值保留 → 兩臂共用同一時間軸
    for (size_t i : idx) {
      q.positions.push_back(p.positions[i]);
      if (p.velocities.size() == full.joint_names.size()) {
        q.velocities.push_back(p.velocities[i]);
      }
      if (p.accelerations.size() == full.joint_names.size()) {
        q.accelerations.push_back(p.accelerations[i]);
      }
    }
    out.points.push_back(std::move(q));
  }
  return out;
}

size_t arg_or(int argc, char ** argv, int idx, size_t fallback)
{
  return (argc > idx) ? static_cast<size_t>(std::strtoul(argv[idx], nullptr, 10)) : fallback;
}

}  // namespace

int main(int argc, char ** argv)
{
  const size_t host_d = arg_or(argc, argv, 1, 10);
  const size_t arm_a_d = arg_or(argc, argv, 2, 11);
  const size_t arm_b_d = arg_or(argc, argv, 3, 12);

  rclcpp::install_signal_handlers();

  DomainNode host = make_domain_node("trajectory_downlink_client", host_d, true);
  DomainNode armA = make_domain_node("downlink_arm_a", arm_a_d, false);
  DomainNode armB = make_domain_node("downlink_arm_b", arm_b_d, false);

  auto state = std::make_shared<SharedState>();
  auto logger = host.node->get_logger();

  // 各臂 context 的發布器（同名 topic、不同 domain）
  auto pub_a = armA.node->create_publisher<JointTrajectory>(kArmTopic, 10);
  auto pub_b = armB.node->create_publisher<JointTrajectory>(kArmTopic, 10);

  // ---- ① 捕捉 RViz Plan 的結果（D10）----
  auto sub_plan = host.node->create_subscription<moveit_msgs::msg::DisplayTrajectory>(
    "/display_planned_path", 10,
    [state, logger](moveit_msgs::msg::DisplayTrajectory::ConstSharedPtr msg) {
      if (msg->trajectory.empty()) {return;}
      std::lock_guard<std::mutex> lk(state->mtx);
      state->latest = msg->trajectory[0].joint_trajectory;
      state->have_plan = true;
      const double dur = state->latest.points.empty() ? 0.0 :
        rclcpp::Duration(state->latest.points.back().time_from_start).seconds();
      RCLCPP_INFO(logger, "[捕捉到新規劃] %zu 軸, %zu 點, 軌跡時長 %.3f 秒 — 可觸發執行",
        state->latest.joint_names.size(), state->latest.points.size(), dur);
    });

  // ---- ⑤ 完成監看的資料來源: D10 合併 /joint_states（前綴名, 上行橋的輸出）----
  auto sub_js = host.node->create_subscription<sensor_msgs::msg::JointState>(
    "/joint_states", 10,
    [state](sensor_msgs::msg::JointState::ConstSharedPtr msg) {
      std::lock_guard<std::mutex> lk(state->mtx);
      for (size_t i = 0; i < msg->name.size() && i < msg->position.size(); ++i) {
        state->current[msg->name[i]] = msg->position[i];
      }
    });

  // ---- ②③④ 觸發執行 ----
  auto host_node = host.node;
  auto srv_exec = host.node->create_service<std_srvs::srv::Trigger>(
    "~/execute",
    [state, pub_a, pub_b, host_node, logger](
      const std_srvs::srv::Trigger::Request::SharedPtr,
      std_srvs::srv::Trigger::Response::SharedPtr res) {
      std::lock_guard<std::mutex> lk(state->mtx);
      if (!state->have_plan || state->latest.points.empty()) {
        res->success = false;
        res->message = "尚未捕捉到規劃結果 (先在 RViz 按 Plan)";
        return;
      }
      JointTrajectory ta = split_and_strip(state->latest, kPrefixA);
      JointTrajectory tb = split_and_strip(state->latest, kPrefixB);
      if (ta.joint_names.empty() || tb.joint_names.empty()) {
        res->success = false;
        res->message = std::string("拆分失敗: 規劃中找不到 ") + kPrefixA + " 或 " +
          kPrefixB + " 開頭的關節";
        return;
      }
      // header.stamp 維持 0 → 各臂收到即跑（不需 NTP; 兩筆連續 publish 差毫秒級）
      pub_a->publish(ta);
      pub_b->publish(tb);

      // 完成監看: 目標用「前綴名」記（跟 D10 合併 joint_states 直接對得上）
      state->targets.clear();
      const auto & last = state->latest.points.back();
      for (size_t i = 0; i < state->latest.joint_names.size(); ++i) {
        state->targets[state->latest.joint_names[i]] = last.positions[i];
      }
      const double dur = rclcpp::Duration(last.time_from_start).seconds();
      state->deadline = host_node->now() +
        rclcpp::Duration::from_seconds(dur * 1.5 + kTimeoutMargin);
      state->executing = true;

      res->success = true;
      res->message = "已發布(跨domain): A 臂 " + std::to_string(ta.points.size()) +
        " 點 / B 臂 " + std::to_string(tb.points.size()) + " 點, 軌跡時長 " +
        std::to_string(dur) + " 秒";
      RCLCPP_INFO(logger, "[執行] %s", res->message.c_str());
    });

  // ---- ⑥ 取消: 各 domain 發空軌跡（標準 JTC 停止語意）----
  auto srv_cancel = host.node->create_service<std_srvs::srv::Trigger>(
    "~/cancel",
    [state, pub_a, pub_b, logger](
      const std_srvs::srv::Trigger::Request::SharedPtr,
      std_srvs::srv::Trigger::Response::SharedPtr res) {
      JointTrajectory empty;
      pub_a->publish(empty);
      pub_b->publish(empty);
      {
        std::lock_guard<std::mutex> lk(state->mtx);
        state->executing = false;
      }
      res->success = true;
      res->message = "已對兩臂(各自 domain)發出空軌跡 (取消當前運動)";
      RCLCPP_WARN(logger, "[取消] %s", res->message.c_str());
    });

  // ---- ⑤ 完成監看 timer（100ms）----
  auto timer = host.node->create_wall_timer(
    std::chrono::milliseconds(100),
    [state, host_node, logger]() {
      std::lock_guard<std::mutex> lk(state->mtx);
      if (!state->executing) {return;}
      bool all_ok = !state->targets.empty();
      for (const auto & [name, target] : state->targets) {
        auto it = state->current.find(name);
        if (it == state->current.end() || std::abs(it->second - target) > kGoalTolerance) {
          all_ok = false;
          break;
        }
      }
      if (all_ok) {
        state->executing = false;
        RCLCPP_INFO(logger, "[完成] 兩臂全部關節到達終點 (容差 %.4f rad)", kGoalTolerance);
      } else if (host_node->now() > state->deadline) {
        state->executing = false;
        RCLCPP_WARN(logger,
          "[逾時] 超過預期時間仍未到終點 — 檢查上行橋是否在跑、控制器是否中止 (topic 模式容差違反會默默中止)");
      }
    });

  RCLCPP_INFO(logger,
    "下行 client 啟動: D%zu 捕捉/監看/服務 → D%zu(A臂) + D%zu(B臂) 發 %s (去前綴)",
    host_d, arm_a_d, arm_b_d, kArmTopic);
  RCLCPP_INFO(logger,
    "觸發執行: ros2 service call /trajectory_downlink_client/execute std_srvs/srv/Trigger");

  host.start();
  armA.start();
  armB.start();
  host.join();
  armA.join();
  armB.join();

  rclcpp::uninstall_signal_handlers();
  return 0;
}
