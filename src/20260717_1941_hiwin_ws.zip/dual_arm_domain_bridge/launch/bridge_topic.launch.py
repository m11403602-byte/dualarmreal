# [來源] 新建檔案 — Plan B 整層橋一鍵啟動: 方案 A（topic 下行, 保守備胎）
# 內容 = 上行橋(必跑) + topic 下行 client
#
# 用法:
#   ros2 launch dual_arm_domain_bridge bridge_topic.launch.py
#   ros2 launch dual_arm_domain_bridge bridge_topic.launch.py host_domain:=10 arm_a_domain:=20 arm_b_domain:=30
#
# 注意:
#   - 此模式「不用」RViz 的 Execute 鈕; 執行/取消走 service:
#       ros2 service call /trajectory_downlink_client/execute std_srvs/srv/Trigger
#       ros2 service call /trajectory_downlink_client/cancel  std_srvs/srv/Trigger
#     （或用 RViz Panel, Panel 的 client node 名需設 /trajectory_downlink_client）
#   - 兩支程式內部用 set_domain_id() 明碼指定 domain（CLI 位置參數）,
#     「不吃」這個終端的 ROS_DOMAIN_ID 環境變數
#   - 與 bridge_relay.launch.py 二選一, 勿同時跑（下行雙重執行）

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    host_domain = LaunchConfiguration("host_domain")
    arm_a_domain = LaunchConfiguration("arm_a_domain")
    arm_b_domain = LaunchConfiguration("arm_b_domain")

    return LaunchDescription([
        DeclareLaunchArgument(
            "host_domain", default_value="10",
            description="主機(brain/move_group/RViz)所在 domain"),
        DeclareLaunchArgument(
            "arm_a_domain", default_value="20",
            description="A 臂(RA610-1476, big_)原廠系統所在 domain"),
        DeclareLaunchArgument(
            "arm_b_domain", default_value="30",
            description="B 臂(RA605-710, small_)原廠系統所在 domain"),

        # 上行橋: D_armA/D_armB 的 /joint_states → 加前綴合併 → D_host /joint_states
        Node(
            package="dual_arm_domain_bridge",
            executable="joint_state_uplink_bridge",
            name="joint_state_uplink_bridge",
            output="screen",
            arguments=[host_domain, arm_a_domain, arm_b_domain],
        ),

        # 下行(方案 A): 捕捉規劃結果 → 拆分去前綴 → 發 JTC topic 介面（service 觸發）
        Node(
            package="dual_arm_domain_bridge",
            executable="trajectory_downlink_client",
            name="trajectory_downlink_client",
            output="screen",
            arguments=[host_domain, arm_a_domain, arm_b_domain],
        ),
    ])
