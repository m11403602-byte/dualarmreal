# dual_arm_domain_bridge — Plan B（domain 隔離）的跨域橋層

手臂端跑「原封不動的原廠 launch」、各自關進獨立 domain；主機(D10)靠本 package
跨域 + 改 joint 名。三支執行檔 + 兩支 launch。

## 執行檔

| 程式 | 角色 | 備註 |
|------|------|------|
| joint_state_uplink_bridge | 上行（眼睛）, **必跑** | 兩臂 /joint_states 加前綴合併 → D10 |
| trajectory_downlink_client | 下行方案 A: topic | service 觸發執行/取消, 保守備胎 |
| trajectory_downlink_endpoint_relay | 下行方案 C: 端點透明轉送 | **首選**; RViz 原生 Execute/Stop, 失敗語意=直連; 已模擬實測全綠 |

下行 A/C 二選一, 勿同時跑。所有執行檔皆接受位置參數 `[host_d armA_d armB_d]`
（內部 set_domain_id 明碼指定, 不吃終端的 ROS_DOMAIN_ID）。

## 一鍵啟動（launch）

```bash
# 方案 C（首選）: 上行橋 + 端點透明轉送
ros2 launch dual_arm_domain_bridge bridge_relay.launch.py
ros2 launch dual_arm_domain_bridge bridge_relay.launch.py host_domain:=10 arm_a_domain:=20 arm_b_domain:=30

# 方案 A（備胎）: 上行橋 + topic client
ros2 launch dual_arm_domain_bridge bridge_topic.launch.py
```

launch 參數: `host_domain`(預設 10) / `arm_a_domain`(預設 20) / `arm_b_domain`(預設 30)。

## 啟動順序（全系統）

```
① A 臂: ROS_DOMAIN_ID=20 ros2 launch hiwin_driver ra6_control.launch.py ra_type:=ra610_1476 ...
② B 臂: ROS_DOMAIN_ID=30 ros2 launch hiwin_driver ra6_control.launch.py ra_type:=ra605_710 ...
③ 橋層: ros2 launch dual_arm_domain_bridge bridge_relay.launch.py
④ 主機: ros2 launch hiwin_dual_arm brain.launch.py launch_rviz:=true（不開 merger）
```

## 方案 C 已知行為（非 bug）

- 取消後 brain/relay 只見 big 的判決書: MoveIt TEM「排隊逐一等」控制器（字母序 b<s）,
  第一張取消判決書回來時執行已定案, 不再請求 small 的 — 直連下行為相同。
- 取消後 RViz 報 `execute() failed`: preempted 在 client 端即以失敗呈現, 正常。

設計細節見 transparent_relay_architecture.md（方案 B action 橋已於定案後移除）。
