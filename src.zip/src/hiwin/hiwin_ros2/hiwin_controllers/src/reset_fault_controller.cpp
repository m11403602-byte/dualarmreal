// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <cinttypes>

#include "hiwin_controllers/reset_fault_controller.hpp"

namespace hiwin_controllers
{
controller_interface::InterfaceConfiguration ResetFaultController::command_interface_configuration() const
{
  controller_interface::InterfaceConfiguration config;
  config.type = controller_interface::interface_configuration_type::INDIVIDUAL;
  config.names.reserve(params_.joints.size() * params_.command_interfaces.size());
  for (const auto& joint_name : params_.joints)
  {
    for (const auto& interface_type : params_.command_interfaces)
    {
      config.names.push_back(joint_name + "/" + interface_type);
    }
  }
  return config;
};

controller_interface::InterfaceConfiguration ResetFaultController::state_interface_configuration() const
{
  controller_interface::InterfaceConfiguration config;
  config.type = controller_interface::interface_configuration_type::INDIVIDUAL;
  config.names.reserve(params_.joints.size() * params_.state_interfaces.size());
  for (const auto& joint_name : params_.joints)
  {
    for (const auto& interface_type : params_.state_interfaces)
    {
      config.names.push_back(joint_name + "/" + interface_type);
    }
  }
  return config;
};

controller_interface::CallbackReturn ResetFaultController::on_init()
{
  try
  {
    param_listener_ = std::make_shared<joint_state_parameters::ParamListener>(get_node());
    params_ = param_listener_->get_params();
  }
  catch (const std::exception& e)
  {
    RCLCPP_ERROR(get_node()->get_logger(), "Error reading parameters: %s", e.what());
    return CallbackReturn::ERROR;
  }
  return controller_interface::CallbackReturn::SUCCESS;
};

controller_interface::CallbackReturn ResetFaultController::on_configure(const rclcpp_lifecycle::State& previous_state)
{
  if (!param_listener_)
  {
    RCLCPP_ERROR(get_node()->get_logger(), "Error encountered during init");
    return controller_interface::CallbackReturn::ERROR;
  }

  param_listener_->refresh_dynamic_parameters();

  params_ = param_listener_->get_params();

  if (get_node()->has_parameter("trajectory_action_server"))
    traj_action_server_ = get_node()->get_parameter("trajectory_action_server").as_string();

  if (get_node()->has_parameter("reset_pulse_sec"))
    reset_pulse_ns_ = static_cast<int64_t>(get_node()->get_parameter("reset_pulse_sec").as_double() * 1e9);

  return controller_interface::CallbackReturn::SUCCESS;
};

controller_interface::CallbackReturn ResetFaultController::on_activate(const rclcpp_lifecycle::State& previous_state)
{
  const auto logger = get_node()->get_logger();

  try
  {
    reset_srv_ = get_node()->create_service<hiwin_msgs::srv::ResetJointFault>(
        "~/reset_fault",
        std::bind(&ResetFaultController::handle_reset, this, std::placeholders::_1, std::placeholders::_2));
  }
  catch (const std::exception& e)
  {
    RCLCPP_ERROR(logger, "Failed to create reset_fault service: %s", e.what());
    return CallbackReturn::ERROR;
  }

  trajectory_client_ = rclcpp_action::create_client<FollowJointTrajectory>(get_node(), traj_action_server_);

  if (!trajectory_client_->wait_for_action_server(std::chrono::seconds(2)))
  {
    RCLCPP_WARN(logger,
                "Trajectory action server '%s' not available yet. "
                "Service calls will fail until it appears.", traj_action_server_.c_str());
  }

  return controller_interface::CallbackReturn::SUCCESS;
};

controller_interface::CallbackReturn ResetFaultController::on_deactivate(const rclcpp_lifecycle::State& previous_state)
{
  reset_srv_.reset();
  trajectory_client_.reset();

  return controller_interface::CallbackReturn::SUCCESS;
};

controller_interface::return_type ResetFaultController::update(const rclcpp::Time& time, const rclcpp::Duration& period)
{
  (void)period;
  const int64_t now_ns = time.nanoseconds();

  std::unordered_map<std::string, int64_t> local_deadline;
  {
    std::lock_guard<std::mutex> lock(reset_mutex_);
    local_deadline = reset_deadline_ns_;
  }

  std::vector<std::string> to_erase;

  for (auto& iface : command_interfaces_)
  {
    const auto& name = iface.get_name();
    if (name.find("/reset_fault") == std::string::npos)
      continue;

    const auto it = local_deadline.find(name);
    if (it != local_deadline.end() && now_ns < it->second)
      iface.set_value(1.0);
    else
    {
      iface.set_value(0.0);
      if (it != local_deadline.end() && now_ns >= it->second)
        to_erase.push_back(name);
    }
  }

  if (!to_erase.empty())
  {
    std::lock_guard<std::mutex> lock(reset_mutex_);
    for (const auto& k : to_erase)
    {
      auto it = reset_deadline_ns_.find(k);
      if (it != reset_deadline_ns_.end() && now_ns >= it->second)
        reset_deadline_ns_.erase(it);
    }
  }

  return controller_interface::return_type::OK;
}

void ResetFaultController::handle_reset(const std::shared_ptr<hiwin_msgs::srv::ResetJointFault::Request> request,
                                        std::shared_ptr<hiwin_msgs::srv::ResetJointFault::Response> response)
{
  const auto logger = get_node()->get_logger();

  const std::string joint_name = request->joint_name;
  const std::string interface_name = joint_name + "/reset_fault";

  if (!trajectory_client_ || !trajectory_client_->wait_for_action_server(std::chrono::seconds(2)))
  {
    response->success = false;
    response->message = "Trajectory action server not available.";
    RCLCPP_ERROR(logger, "%s", response->message.c_str());
    return;
  }

  auto goal = FollowJointTrajectory::Goal();
  goal.trajectory.header.stamp = rclcpp::Time(0);
  goal.trajectory.joint_names.push_back(joint_name);

  trajectory_msgs::msg::JointTrajectoryPoint pt;
  pt.time_from_start = rclcpp::Duration::from_seconds(0);

  auto it = std::find_if(state_interfaces_.begin(), state_interfaces_.end(),
                         [&](const auto& iface) { return iface.get_name() == joint_name + "/position"; });
  if (it == state_interfaces_.end())
  {
    response->success = false;
    response->message = "No position interface for joint " + joint_name;
    RCLCPP_ERROR(logger, "%s", response->message.c_str());
    return;
  }

  pt.positions.push_back(it->get_value());
  goal.trajectory.points.push_back(pt);

  rclcpp_action::Client<FollowJointTrajectory>::SendGoalOptions options;
  options.result_callback = [this, interface_name](auto result) {
    auto logger = get_node()->get_logger();

    if (result.result->error_code == control_msgs::action::FollowJointTrajectory::Result::SUCCESSFUL)
    {
      const int64_t until_ns = get_node()->get_clock()->now().nanoseconds() + reset_pulse_ns_;
      std::lock_guard<std::mutex> lock(reset_mutex_);
      auto& slot = reset_deadline_ns_[interface_name];
      if (slot < until_ns)
        slot = until_ns;
      RCLCPP_INFO(logger, "Reset pulse for %s until %" PRId64 " ns.", interface_name.c_str(), until_ns);
    }
    else
    {
      RCLCPP_WARN(logger, "Trajectory failed for %s: code = %d", interface_name.c_str(), result.result->error_code);
    }
  };
  trajectory_client_->async_send_goal(goal, options);

  // Immediate service response
  response->success = true;
  response->message = "Trajectory goal sent. Waiting for result asynchronously.";
}

}  // namespace hiwin_controllers

#include "pluginlib/class_list_macros.hpp"

PLUGINLIB_EXPORT_CLASS(hiwin_controllers::ResetFaultController, controller_interface::ControllerInterface)